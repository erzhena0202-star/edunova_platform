# EduNova website

A static website: landing page, My Profile, My Courses, Community with chat rooms, Settings, and lesson pages.
No build step, no server code. Just upload the folder.

## What's inside

```
edunova-site/
├── index.html          the whole site (HTML, CSS and JavaScript in one file)
├── assets/
│   ├── hero.png        3D character illustration
│   └── logo_mask.png   EduNova logo (colored by CSS, works in light and dark mode)
└── README.md
```

## Try it on your computer

Double-click `index.html` to open it in your browser.
If the logo or illustration doesn't show, run a tiny local server from this folder instead:

```
python3 -m http.server 8000
```

then open http://localhost:8000

## Put it online (free options)

**Netlify Drop** (easiest)
1. Go to https://app.netlify.com/drop
2. Drag the whole `edunova-site` folder onto the page.
3. You get a public link in a few seconds. You can rename it in Site settings.

**GitHub Pages**
1. Create a new repository on GitHub and upload these files (keep the `assets` folder).
2. Settings → Pages → Source: "Deploy from a branch", branch `main`, folder `/ (root)`.
3. Your site appears at `https://<your-username>.github.io/<repo-name>/`.

**Vercel**
1. Go to https://vercel.com/new and import the GitHub repository (or drag the folder in).
2. Framework preset: "Other". Deploy.

## Pages and links

| Page | Address |
|---|---|
| Landing page | `index.html` |
| My Profile | `index.html#profile` |
| My Courses | `index.html#mycourses` |
| Community | `index.html#community` |
| Chat room | `index.html#room-ai`, `#room-frontend`, `#room-ml`, `#room-uxui` |
| Settings | `index.html#settings` |
| Lessons | `index.html#lesson-uxui`, `#lesson-ai` |

## Good to know

- Everything is demo data. There are no real accounts, logins, payments or chat servers yet;
  messages, filters and settings live only in the open browser tab.
  Lesson notes are saved in the visitor's own browser (localStorage).
- To change text, open `index.html` in any code editor (VS Code is free) and edit it.
  Course, room and lesson data are near the bottom of the file in plain lists
  (`COURSES`, `PROG`, `SAVED`, `DONE`, `ROOMS`, `LESSONS`).
- To add another YouTube lesson, add an entry to `LESSONS` and link to it with `#lesson-<name>`.
- The site uses the Inter font from Google Fonts, so it needs an internet connection to look right.
